/*
 * JavaScript for WikiEditor Publish module
 */

$( document ).ready( function() {
	// Add publish module
	$( '#wpTextbox1' ).wikiEditor( 'addModule', 'publish' );
} );
